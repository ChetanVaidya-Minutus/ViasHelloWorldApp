import setuptools

setuptools.setup(
    install_requires=[
        # "simple-hello-world-package==0.0.1"
    ]
)
